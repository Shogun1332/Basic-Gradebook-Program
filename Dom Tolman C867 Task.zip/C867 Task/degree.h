//Definition of enumerated data type for Degree Program
#pragma once
#include <iostream>
#include <string>

using namespace std;

enum eDegreeProgram { SECURITY, NETWORK, SOFTWARE };
static string degreeProgramStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" };
